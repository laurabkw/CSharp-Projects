﻿using System;

namespace aula3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite nome, idade, peso");
            string[] vetor = new string[3];

            string nome;
            int idade;
            double peso;

            vetor = Console.ReadLine().Split(' ');
            nome = vetor[0];
            idade = int.Parse(vetor[1]);
            peso =double.Parse(vetor[2]);

            Console.WriteLine(nome);
            Console.WriteLine(idade);
            Console.WriteLine(peso.ToString("F2"));
            
            
        }
    }
}
