﻿using System;
using System.Threading;

namespace aula10_programacao_orientada_objeto
{
    public class Pessoa{
        //propriedades da classe

        //tipo nome;
        public string Cpf;

        public string Nome;

        double SaldoConta;

        //construtor default
        public Pessoa(){}

        //construtor com parâmetros
        //parametro: tipo nome
        public Pessoa(string Nome){
            this.Nome = Nome;
        }

        public Pessoa(string Cpf, string Nome, double SaldoInicial){
            this.Cpf = Cpf;
                this.Nome = Nome;
                this.SaldoConta = SaldoInicial;
        }

        //Métodos
        //método: tipo de retorno, nome do método(){codigo...}
        public void Correr(){
            //TODO
            Console.WriteLine("Correndo...");
            //delay
            Thread.Sleep(1000);
        }
        public void Parar(){
            //TODO
            Console.WriteLine("Parando...");
            Thread.Sleep(1000);
            Console.WriteLine("Parou.");
        }
        public void DepositarDinheiro(double Valor){
            this.SaldoConta += Valor;
            Console.WriteLine("Depositando dinheiro...");
            Thread.Sleep(2000);
            Console.WriteLine("Deposito efetuado.");
        }
        public void SacarDinheiro(double Valor){
            this.SaldoConta -= Valor;
            Console.WriteLine("Sacando dinheiro...");
            Thread.Sleep(2000);
            Console.WriteLine("Saque efetuado.");
        }
        public double ConsultarSaldo(){
            Console.WriteLine("Consultando saldo...");
            Thread.Sleep(2000);
            return this.SaldoConta;
        }
    }
    
    class Program{
        static void Main(string[] args)
        {
            //instaciar objetos
            //criar variáveis na memória baseado em uma classe
            //objetos: são instâncias de classes
            //tipo, nome =new=instanciar
            Pessoa pessoa = new Pessoa();
            pessoa.Nome = "Maria";
            pessoa.Cpf = "24951736985";

            pessoa.Correr();
            pessoa.Parar();
            pessoa.DepositarDinheiro(100.00);

            Console.WriteLine("Pessoa 1: Nome: "+ pessoa.Nome);
            Console.WriteLine("Pessoa 1: Cpf: "+ pessoa.Cpf);
            Console.WriteLine("Pessoa 1: Saldo: "+ pessoa.ConsultarSaldo());
            pessoa.Correr();
            pessoa.Parar();
            pessoa.SacarDinheiro(10.00);

            Console.WriteLine("Pessoa 1: Saldo: "+ pessoa.ConsultarSaldo());


            Pessoa pessoa2 = new Pessoa("Laura Waechter");
            Console.WriteLine("Pessoa 2: Nome: "+ pessoa2.Nome);
            Console.WriteLine("Pessoa 2: Cpf: "+ pessoa.Cpf);
            Console.WriteLine("Pessoa 2: Saldo: "+ pessoa.ConsultarSaldo());

            pessoa.Correr();
            pessoa2.Parar();
            pessoa2.DepositarDinheiro(500.00);
            Console.WriteLine("Pessoa 2: Saldo: "+ pessoa.ConsultarSaldo());
            pessoa2.SacarDinheiro(100.00);
            Console.WriteLine("Pessoa 2: Saldo: "+ pessoa.ConsultarSaldo());
        }
    }
}