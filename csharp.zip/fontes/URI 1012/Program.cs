﻿using System;
using System.Globalization;

namespace URI_1012
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] vetor;
            double A, B, C, TRIANGULO, CIRCULO, TRAPEZIO, QUADRADO, RETANGULO;
            vetor=Console.ReadLine().Split(' ');
            A=double.Parse(vetor[0],CultureInfo.InvariantCulture);
            B=double.Parse(vetor[1],CultureInfo.InvariantCulture);
            C=double.Parse(vetor[2],CultureInfo.InvariantCulture);
            TRIANGULO = (A * C)/2 ;
            CIRCULO = 3.14159*Math.Pow(C,2) ;
            TRAPEZIO = (A + B)*C/2 ;
            QUADRADO = Math.Pow(B,2) ;
            RETANGULO = A * B ;
            Console.WriteLine("TRIANGULO: "+ TRIANGULO.ToString("f3",CultureInfo.InvariantCulture));
            Console.WriteLine("CIRCULO: "+ CIRCULO.ToString("f3",CultureInfo.InvariantCulture));
            Console.WriteLine("TRAPEZIO: "+ TRAPEZIO.ToString("f3",CultureInfo.InvariantCulture));
            Console.WriteLine("QUADRADO: "+ QUADRADO.ToString("f3",CultureInfo.InvariantCulture));
            Console.WriteLine("RETANGULO: "+ RETANGULO.ToString("f3",CultureInfo.InvariantCulture));
        }
    }
}
