﻿using System;

namespace URI_1080
{
    class Program
    {
        static void Main(string[] args)
        {
            int maior;
            int posicao=1;
            int entrada=int.Parse(Console.ReadLine());
            maior=entrada;

            for (int x=2; x<=100;x++){
                entrada=int.Parse(Console.ReadLine());

                if(entrada>maior){
                    maior=entrada;
                    posicao=x;
                }
            }
            Console.WriteLine(maior);
            Console.WriteLine(posicao);
        }
    }
}
