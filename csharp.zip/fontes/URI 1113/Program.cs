﻿using System;

namespace URI_1113
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variáveis
            string[] vetor;
            int X, Y;

            //Entrada
            vetor=Console.ReadLine().Split(' ');
            X=int.Parse(vetor[0]);
            Y=int.Parse(vetor[1]);
            
            //enquato X for diferente de Y
            while (X != Y){
                //se X é menor que Y 
                if(X<Y){
                    Console.WriteLine("Crescente");
                }else{
                    Console.WriteLine("Decrescente");
                }
                //ler valores novamente
                vetor=Console.ReadLine().Split(' ');
                X=int.Parse(vetor[0]);
                Y=int.Parse(vetor[1]);
            }
            //Saída

        }
    }
}
