﻿using System;
using System.Globalization;

namespace aula8_exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            int N;
            //leitura de N
            N=int.Parse(Console.ReadLine());
            //leitura dos valores em formato de texto
            string[] linha=Console.ReadLine().Split();
            //declaração do vetor ecriação de instância
            double[] valores=new double[N];

            double media,soma=0.0;

            //percorre valor texto e atribui valores
            for(int i=0;i<N;i++){
                valores[i]=double.Parse(linha[i],CultureInfo.InvariantCulture);
                soma+=valores[i];
            }

            media=soma/N;

            for(int i=0;i<N;i++){
                Console.WriteLine(valores[i].ToString("F1",CultureInfo.InvariantCulture) + " ");
            }
            Console.WriteLine();
            Console.WriteLine(soma.ToString("F2",CultureInfo.InvariantCulture));
            Console.WriteLine(media.ToString("F2",CultureInfo.InvariantCulture));
        }
    }
}
