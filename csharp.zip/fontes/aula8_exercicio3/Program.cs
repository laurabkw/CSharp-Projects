﻿using System;

namespace aula8_exercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int N=int.Parse(Console.ReadLine());
            int[] idades=int.Parse(Console.ReadLine());
            double[] alturas=double.Parse(Console.ReadLine());
            string[] nomes=Console.ReadLine();

            for(int i=0;i<N;i++){
                string[]linha;
            }
            
        }
    }
}
