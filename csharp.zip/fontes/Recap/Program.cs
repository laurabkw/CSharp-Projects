﻿using System;

namespace Recap
{
    class Program
    {
        static void Main(string[] args)
        {
            // declarar vaiáveis primitivas
            int idade = 17;
            double peso = 60.5;
            string nome = "Laura Waechter";
            var sobrenome = "Waechter";
            int distancia;
            char letra = 'A';
            decimal totalVenda = 0;
            bool ehVerdadeEsseBilhete = false;

            //complexas
            String frase = "Quero ver, outra vez, seus olhinhos na noite serena";
            Double subTotal = 0;


            Console.Write("Digite a sua idade: ");
            //idade recebe string do teclado e converte para inteiro
            idade = int.Parse(Console.ReadLine());

            Console.Write("Digite seu peso: ");
            peso = double.Parse(Console.ReadLine());

            Console.Write("Digite o seu nome: ");
            nome = Console.ReadLine();

            Console.Write("Digite o seu sobrenome: ");
            sobrenome = Console.ReadLine();

            Console.Write("Quantos quilômetros você ja correu? ");
            distancia = int.Parse(Console.ReadLine());

            Console.Write("Digite o total da venda: ");
            totalVenda = decimal.Parse(Console.ReadLine());

            Console.Write("Você leu os slides da aula passada?(s/n) ");
            var entrada = Console.ReadLine();
            ehVerdadeEsseBilhete = entrada == "s"? true:false;
            
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Dados Informados");
            Console.WriteLine("------------------------------");
            Console.WriteLine("Idade: " + idade);
            Console.WriteLine("Peso: " + peso);
            Console.WriteLine("Nome: " + nome);
            Console.WriteLine("Sobrenome: " + sobrenome);
            Console.WriteLine("Kms: " + distancia);
            Console.WriteLine("Total da Venda: " + totalVenda);
            Console.WriteLine("Leu os slides: " + ehVerdadeEsseBilhete);
            Console.WriteLine("------------------------------");
            //altera a cor das letras novamente para branco
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
