﻿using System;
using System.Globalization;

namespace URI_1011
{
    class Program
    {
        static void Main(string[] args)
        {
            int raio;
            double VOLUME;
            raio=int.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            VOLUME =(4.0/3.0)*3.14159*Math.Pow(raio,3);
            Console.WriteLine("VOLUME = "+ VOLUME.ToString("f3",CultureInfo.InvariantCulture));
        }
    }
}
