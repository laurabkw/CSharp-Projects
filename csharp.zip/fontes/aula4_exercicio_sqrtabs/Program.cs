﻿using System;
using System.Globalization;

namespace aula4_exercicio_sqrtabs
{
    class Program
    {
        static void Main(string[] args)
        {
            double valor, raiz;
            Console.Write("Informe um valor: ");
            valor=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            raiz=Math.Sqrt(valor);
            Console.WriteLine("Raiz Quadrada de " + valor + ": " + raiz);
        }
    }
}
