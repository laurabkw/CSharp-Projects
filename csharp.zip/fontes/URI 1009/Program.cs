﻿using System;
using System.Globalization;

namespace URI_1009
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;
            double total, salario, vendas;

            nome=Console.ReadLine();
            salario=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            vendas=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            total = salario+(vendas*0.15);
            Console.WriteLine("TOTAL = R$ "+ total.ToString("f2",CultureInfo.InvariantCulture));
        }
    }
}
