﻿using System;
using System.Globalization;

namespace URI_1036
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] vetor;
            double A, B, C, x1, x2;
            vetor = Console.ReadLine().Split(' ');
            A = double.Parse(vetor[0], CultureInfo.InvariantCulture);
            B = double.Parse(vetor[1], CultureInfo.InvariantCulture);
            C = double.Parse(vetor[2], CultureInfo.InvariantCulture);

            double delta = (B * B) - (4 * A * C);

            if (A == 0.0 || B == 0.0 || C == 0.0 || delta < 0)
            {
                Console.WriteLine("Impossivel calcular");
            }
            else
            {
                x1 = ((B * -1.0) + Math.Sqrt(delta)) / (2 * A);
                x2 = ((B * -1.0) - Math.Sqrt(delta)) / (2 * A);
                Console.WriteLine("R1 = " + x1.ToString("F5"), CultureInfo.InvariantCulture);
                Console.WriteLine("R2 = " + x2.ToString("F5"), CultureInfo.InvariantCulture);
            }
        }
    }
}