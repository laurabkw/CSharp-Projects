﻿using System;
using System.Globalization;

namespace aula7_exercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            char repetir;
            //faça
            do{
                //imprime na saída o que o usuário deve informar
                Console.Write("Digite a temperatura em Celsius: ");
                //criar variável double e atribui o valor do teclado a ela
                double celsius=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
                double fahrenheit=(celsius*9.0)/5.0+32;

                Console.WriteLine("Equivalente em Fahrenheit "+fahrenheit.ToString("F1",CultureInfo.InvariantCulture));
                Console.WriteLine("Deseja repetir (s/n)? ");
                //atribui a variável repetir o valor digitado no teclado
                //e passa 
                repetir=char.Parse(Console.ReadLine().ToLower());
            }
            //Enquanto
            while(repetir=='s');
        }
    }
}
