﻿using System;
using System.Globalization;

namespace aula5_exercicio_revisao
{
    class Program
    {
        static void Main(string[] args)
        {
            int tempo,vm;
            double litros;
            tempo=int.Parse(Console.ReadLine());
            vm=int.Parse(Console.ReadLine());
            litros = (double) tempo * vm / 12;
            Console.WriteLine(litros.ToString("f3",CultureInfo.InvariantCulture));
        }
    }
}
