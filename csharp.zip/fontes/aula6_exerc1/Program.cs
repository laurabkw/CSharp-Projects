﻿using System;
using System.Globalization;

namespace aula6_exerc1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variáveis
            double nota1, nota2, notaFinal;

            // Entrada 
            // 45.5
            // 31.3
            nota1=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            nota2=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            notaFinal=nota1+nota2/2.0;

            // Saída
            // NOTA FINAL = 57.5
            // REPROVADO
            Console.WriteLine("NOTA FINAL = " + notaFinal.ToString("F1",CultureInfo.InvariantCulture));
            if(notaFinal<60.0){
                Console.WriteLine("REPROVADO");
                
            }
        }
    }
}
