﻿using System;
using System.Globalization;

namespace URI_1037
{
    class Program
    {
        static void Main(string[] args)
        {
            double A=double.Parse(Console.ReadLine(),CultureInfo.InvariantCulture);
            if(A>0 && A<=100.00)
            {
                Console.WriteLine("Fora de intervalo");
            }
            else
            if(A>=0 && A<=25.00)
            {
                Console.WriteLine("Intervalo (0,25]");
            }
            else
            if(A>=25.01 && A<=50.00)
            {
                Console.WriteLine("Intervalo (25,50]");
            }
            else
            if(A>=50.01 && A<=75.00)
            {
                Console.WriteLine("Intervalo (50,75]");
            }
            else
            if(A>=75.01 && A<=100.00)
            {
                Console.WriteLine("Intervalo (75,100]");
            }
        }
    }
}
