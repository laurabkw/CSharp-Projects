﻿using System;

namespace checklist
{
    class Program
    {
        static void Main(string[] args)
        {
            //ler int
            //ler char 
            //ler double 
            //ler nome, idade, sexo, altura 
            //ler string, int, char, double 

            Console.WriteLine("Digite nome, sexo, idade, altura: ");
            string[] vetor = new string[4];

            string nome;
            int idade;
            double altura;
            char sexo;

            vetor = Console.ReadLine().Split(' ');
            nome = vetor[0];
            sexo =char.Parse(vetor[1]);
            idade = int.Parse(vetor[2]);
            altura =double.Parse(vetor[3]);
            

            Console.WriteLine(nome + " ");
            Console.WriteLine(sexo + " ");
            Console.WriteLine(idade + " ");
            Console.WriteLine(altura.ToString("F2") + " ");
            
    
        }
    }
}
