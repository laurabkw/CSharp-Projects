﻿using System.ComponentModel.DataAnnotations;

namespace EmprestimoLivros.Models
{
    public class EmprestimosModel
    {
        public int Id { get; set; }

        //obrigatório preencher o item, mostra mensagem de erro se estiver vazio
        [Required(ErrorMessage = "Digite o nome do Recebedor!")]
        public string Recebedor { get; set; }

        [Required(ErrorMessage = "Digite o nome do Fornecedor!")]
        public string Fornecedor { get; set; }

        [Required(ErrorMessage = "Digite o nome do Livro Emprestado!")]
        public string LivroEmprestado { get; set; }

        //DateTime.now pega o horário atual do sistema
        public DateTime dataUltimaAtualizacao { get; set; } = DateTime.Now;
    }
}
