﻿using EmprestimoLivros.Data;
using EmprestimoLivros.Models;
using Microsoft.AspNetCore.Mvc;

namespace EmprestimoLivros.Controllers
{
    public class EmprestimoController : Controller
    {
        //propriedades private possuem underline no nome
        readonly private ApplicationDbContext _db;

        //comunicação com o banco de dados
        public EmprestimoController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            //entra no banco de dados e pega toda a tabela de nome Emprestimos
            IEnumerable<EmprestimosModel> emprestimos = _db.Emprestimos;

            return View(emprestimos);
        }

        [HttpGet]
        public IActionResult Cadastrar()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if(id == null || id == 0)
            {
                return NotFound();
            }

            //equivalente a fazer 'select * from Emprestimos where id = id'
            EmprestimosModel emprestimo = _db.Emprestimos.FirstOrDefault(x => x.Id == id);

            if (emprestimo == null)
            {
                return NotFound();
            }

            return View(emprestimo);
        }

        //Httppost faz com que o método abaixo torne-se Post
        [HttpPost]
        public IActionResult Cadastrar(EmprestimosModel emprestimos)
        {
            if (ModelState.IsValid)
            {
                //_db=entra no banco de dados>dentro da tabela Emprestimos>adicionando um item>adiciona a model de emprestimos
                _db.Emprestimos.Add(emprestimos);

                //SaveChanges salva as mudanças feitas na tabela do banco de dados
                _db.SaveChanges();

                TempData["MensagemSucesso"] = "Cadastro Realizado com Sucesso!";
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpPost]
        public IActionResult Editar(EmprestimosModel emprestimo)
        {
            if (ModelState.IsValid)
            {
                _db.Emprestimos.Update(emprestimo);
                _db.SaveChanges();
                TempData["MensagemSucesso"] = "Edição Realizada com Sucesso!";

                return RedirectToAction("Index");
            }
            TempData["MensagemErro"] = "Algum Erro Ocorreu ao Realizar a Edição!";

            return View(emprestimo);
        }

        [HttpGet]
        public IActionResult Excluir(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            EmprestimosModel emprestimo = _db.Emprestimos.FirstOrDefault(x => x.Id == id);

            if (emprestimo == null)
            {
                return NotFound();
            }

            return View(emprestimo);
        }

        [HttpPost]
        public IActionResult Excluir(EmprestimosModel emprestimo)
        {
            if (emprestimo == null)
            {
                return NotFound();
            }

            _db.Emprestimos.Remove(emprestimo);
            _db.SaveChanges();
            TempData["MensagemSucesso"] = "Exclusão Realizada com Sucesso!";

            return RedirectToAction("Index");
        }

    }
}
